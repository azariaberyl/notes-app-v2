import React from 'react';

const NotFoundPage = () => {
  return (
    <div>
      <h3>404</h3>
      <p>Page not found</p>
    </div>
  );
};

export default NotFoundPage;
